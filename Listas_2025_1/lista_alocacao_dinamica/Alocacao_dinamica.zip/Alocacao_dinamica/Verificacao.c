#include <stdio.h>
#include<stdlib.h>
#include<stdbool.h>

bool checkifExist(int*arr, int arrSize){
    for(int i=0; i<arrSize;i++){
        for(int j=0; j<arrSize;j++){
            if(i!=j){
                if(0<=i && j<arrSize){
                    if(arr[i]==2*arr[j]){
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

int *lerVetor(int *size){
    int capacidade=2, numeros; 
    int *vetor=(int *)malloc(capacidade*sizeof(int));
    *size=0;
    printf("Digite números ou -1 para parar: \n");
    while(1){
        scanf("%d",&numeros);
        if(numeros==-1){
            break;
        }
        if(*size>=capacidade){
            capacidade*=2;
            int *realocar= realloc(vetor,capacidade*sizeof(int));
            if(realocar==NULL){
                printf("Erro em realocar memória!\n");
                free(vetor);
                exit(1);
            }
            vetor=realocar;
        }
       vetor[*size]=numeros;
       (*size)++;

    }
    return vetor;

}

int main(){
    int *vet;
    int tamanho; 

    printf("Digite o primeiro vetor: \n"); 
    vet= lerVetor(&tamanho); 
    bool resultado= checkifExist(vet,tamanho);
    if(resultado== false){
        printf("Elemento não safisfaz condições. ");
    }else{
        printf("Existe elemento que satisfaz a condição");
    }
}