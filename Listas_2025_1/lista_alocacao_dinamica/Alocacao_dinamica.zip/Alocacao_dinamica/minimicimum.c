 #include <stdio.h>
 #include <stdlib.h>
 
 int elementMin(int *nums, int nums1Size, int *nums2, int nums2Size){

    int menorComum, encontrada=0;
    for(int i=0; i<nums1Size;i++){
        for(int j=0; j<nums2Size;j++){
            if(nums[i]==nums2[j]){
                if(!encontrada||nums[i]<menorComum){
                    menorComum=nums[i];
                    encontrada=1;
                }
            }

        }
    }
    if(!encontrada){
        return -1;
    }else{
        return menorComum;
    }
 }

 int *lerVetores( int *Size){
    int capacidade= 2; 
    int *nums=(int *)malloc(capacidade*sizeof(int));
    int valores; 
    *Size=0;
        printf("Digite números ou -1 para sair: \n");
    while(1){
        scanf("%d",&valores);
        if(valores==-1){
            break;
        }
        if(*Size>=capacidade){
            capacidade*=2;
            int *realocar= realloc(nums,capacidade*sizeof(int));
            if(realocar==NULL){
                printf("Erro em realocar memória!\n");
                free(realocar);
                exit(1);
            }
            nums=realocar;
        }
       nums[*Size]=valores;
       (*Size)++;

    }
    return nums;

 }

 int main(){
    int *vet1;
    int *vet2;
    int tamanho1, tamanho2;

   printf("prencha 0 1º vetor: \n");
   vet1=lerVetores(&tamanho1);
   printf("prencha 0 2º vetor: \n");
   vet2=lerVetores(&tamanho2);

   int resultado= elementMin(vet1,tamanho1,vet2,tamanho2);

   if(resultado==-1){
    printf("Não há elementos minimos em comum");
   }else{
    printf("O elemento em comum é %d \n",resultado);
   }
 }