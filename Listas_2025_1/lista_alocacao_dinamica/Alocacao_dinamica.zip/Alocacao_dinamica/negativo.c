#include<stdio.h>
#include<stdlib.h>

int countNegatives(int **grid, int m, int n){
    int cont=0;
    for(int i=0; i<m ; i++){
        for(int j=0; j<n; j++){
            if(grid[i][j]<0){
                cont++;
            }

        }
    }
    return cont;
}

int main(){
    int **matriz; 
    int l, c; 
    printf("Digite o tamanho da matriz: \n");
    scanf("%d%d",&l, &c);
    matriz= (int**)malloc(l*sizeof(int*)); 
        if(matriz==NULL){
            printf("Erro de alocação ");
            exit(1);
        }
        for(int i=0; i<l; i++){
            matriz[i]= (int *)malloc(c*sizeof(int));
            if(matriz[i]==NULL){
                printf("Erro de alocação \n");
                exit(1);
            }
        }

        for(int i=0; i<l; i++){
            for(int j=0; j<c; j++){
                printf("Digite o elemento[%d][%d]:\n",i,j);
                scanf("%d", &matriz[i][j]);
            }
        }
        int resultado= countNegatives(matriz, l, c);
        printf("O números de elementos negativos na matriz é: %d",resultado);

}