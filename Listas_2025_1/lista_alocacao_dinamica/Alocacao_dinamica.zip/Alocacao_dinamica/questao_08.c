#include<stdio.h>
#include<stdlib.h>

typedef struct{
    
}Ataques;
