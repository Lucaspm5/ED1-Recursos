#include<stdio.h>
#include<stdlib.h>

int *transformarnum(int a, int b, int *tamanho){
    int capacidade=0;
    int *nums=NULL; 
    nums=realloc(nums,sizeof(int));
    nums[capacidade++]=b;
    while(a<b){
        if(b%10==1){
            b=(b-1)/10;
        }else if(b%2==0){
            b=b/2;
        }else{
            free(nums); 
            return NULL;       
        }
        nums= realloc(nums,(capacidade+1)*sizeof(int));
        nums[capacidade++]=b;
    }
    if(b==a){
        *tamanho=capacidade;
        return nums;
    }else{
        free(nums);
        return NULL;
    }
}

int main(){
    int num1, num2; 
    int *vetor, tam=0; 
    printf("Digite o 1º número: \n");
    scanf("%d",&num1);
    printf("Digite o 2º número: \n");
    scanf("%d",&num2);
    vetor= transformarnum(num1,num2,&tam);
    if(vetor==NULL){
        printf("Não foi possivel fazer as contas.\n");
    }else{
        printf("Foi possível! \n");
        for(int i=tam-1; i>=0;i--){
            printf("%d \n",vetor[i]);
        }
    }
    free(vetor);
}
