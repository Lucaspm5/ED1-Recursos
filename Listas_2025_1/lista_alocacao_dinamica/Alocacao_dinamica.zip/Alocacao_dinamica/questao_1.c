 #include <stdio.h>
 #include<stdlib.h>
 int numeroAusente(int *nums, int numsSize){
    int soma_esperada= numsSize*(numsSize+1)/2;
    int soma=0; 

    for(int i=0; i<numsSize;i++){
        soma+=nums[i];
    }
    return soma_esperada-soma;
 }

 int main(){
    int * vet; 
    int n,resul;
    printf(" Digite a quantidade de numeros que deseja digitar: \n");
    scanf("%d",&n);
    vet= (int *)malloc(n*sizeof(int));
    printf("Digite números do intervalo[0, %d] com um numero faltando \n",n);
    for(int i=0; i<n;i++){
        scanf("%d",&vet[i]);
    }
    resul= numeroAusente(vet,n);
    printf("O número faltando é %d",resul);

    free(vet);
 }