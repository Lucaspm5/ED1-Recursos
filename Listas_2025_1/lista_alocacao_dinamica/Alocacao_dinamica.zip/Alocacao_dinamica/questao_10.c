#include<stdio.h>
#include<stdlib.h>

int soma_elementos_bons(int **mat,int **vis, int n){
    int soma=0, central= (n-1)/2; 
    for(int i=0; i<n; i++){
        for(int j=0;j<n;j++ ){
             if(!(i==j|| i+j==n-1|| i==central|| j== central)){
             if(vis[i][j]==0){
                soma+=mat[i][j];
                vis[i][j]=1;
           } 
        }
        }
    }
    return soma;
    

}

int main(){
    int **matriz;
    int **visitante; 

    int n, resultado; 

    printf("Digite a dimensão da matriz: (apenas números ímpares:)");
    scanf("%d",&n);
        while(n%2==0){
            printf("Erro! Digite a dimensão da matriz: (apenas números ímpares:)");
            scanf("%d",&n);
        }

        matriz= (int**)malloc(n*sizeof(int*)); 
        visitante= (int**)malloc(n*sizeof(int*)); 

        if(matriz==NULL|| visitante==NULL){
            printf("Erro de alocação ");
            exit(1);
        }

        for(int i=0; i<n; i++){
            matriz[i]= (int *)malloc(n*sizeof(int));
            visitante[i] = (int *)calloc(n, sizeof(int));
        }


        for(int i=0; i<n;i++){
            for(int j=0; j<n; j++){
                printf("Digite o valor para [%d][%d]: \n",i,j);
                scanf("%d",&matriz[i][j]);
            }
        }
    resultado= soma_elementos_bons(matriz,visitante,n);
    printf("Resultado é %d ",resultado);
}