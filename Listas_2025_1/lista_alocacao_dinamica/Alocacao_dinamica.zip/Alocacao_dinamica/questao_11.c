#include<stdio.h>
#include<stdlib.h>

int *triangulo_pascal(int **mat, int tam, int *nums){
    for(int i=0; i<=tam;i++){
        mat[i][0]=1;
        mat[i][i]=1;
        for(int j=1;j<i;j++){
            mat[i][j]= mat[i-1][j-1]+mat[i-1][j];
        }
    }

    for(int j=0; j<=tam; j++){
        nums[j]=mat[tam][j];
    }

    return nums;
}

int main(){
    int n; 
    int **pascal;
    int*linha;
    printf("Digite o índice da linha pascal: \n");
    scanf("%d",&n);

    pascal=(int**)malloc((n+1)*sizeof(int*));
    if (pascal == NULL) {
        printf("Erro de alocação!\n");
        exit(1);
    }

    for(int i=0; i<=n;i++){
        pascal[i]=(int*)malloc((i+1)*sizeof(int));
        if (pascal[i] == NULL) {
            printf("Erro de alocação!\n");
            exit(1);
        }
    }

    linha=(int*)malloc((n+1)*sizeof(int));
    if (linha == NULL) {
        printf("Erro de alocação!\n");
        exit(1);
    }

    linha= triangulo_pascal(pascal,n,linha);

    for(int i=0; i<n; i++){
         printf("%d, ",linha[i]);
    }
   


}