#include<stdio.h>
#include<stdlib.h>

typedef struct{
    int *dados;
    int tamanho;
    int capacidade;
}Vector;

Vector* criarVector(int capacidadeInicial); 
int push_back(Vector* v, int elemento); 
int push(Vector *v, int elemento, int index);
int pop(Vector *v, int index); 
int pop_Back(Vector* v); 
int size(Vector *v); 
void free_vector(Vector *v); 
void clear(Vector *v);

Vector* criarVector(int capacidadeInicial){
    Vector *vet = (Vector*)malloc(sizeof(int));
    if(vet==NULL) return NULL;

    vet->dados= (int*)malloc(capacidadeInicial*sizeof(int));
    if(vet->dados==NULL){
        free(vet);
        return NULL;
    }

    vet->tamanho=0;
    vet->capacidade=capacidadeInicial;
    return vet;
}

int push_back(Vector* v, int elemento){
    if(v->tamanho==v->capacidade){
        int n_capacidade= v->capacidade*2;
        int novo_vetor= realloc(v->dados, n_capacidade*sizeof(int));
        if(novo_vetor==NULL){
            return 0;
        }
       v->dados= novo_vetor;
       v->capacidade=n_capacidade;
    }
    v->dados[v->tamanho++]= elemento;
    return 1;
}

int push(Vector *v, int elemento, int index){
    if (index < 0 || index > v->tamanho) return 0;
    if(v->tamanho==v->capacidade){
        int n_capacidade= v->capacidade*2;
        int novo_vetor= realloc(v->dados, n_capacidade*sizeof(int));
        if(novo_vetor==NULL){
            return 0;
        }
       v->dados= novo_vetor;
       v->capacidade=n_capacidade;
    }

    for(int i=v->tamanho;i > index; i--){
        v->dados[i]=v->dados[i-1];
    }

    v->dados[index] = elemento;
    v->tamanho++;
    return 1;

}

int pop(Vector *v, int index){
    if (index < 0 || index >= v->tamanho) return 0;
    for (int i = index; i < v->tamanho - 1; i++) {
        v->dados[i] = v->dados[i + 1];
    }

    v->tamanho--;
    return 1;

}

int pop_Back(Vector* v){
    if (v->tamanho == 0) return 0;
    v->tamanho--;
    return 1;
}

int size(Vector *v){
    return v->tamanho;
}

void free_vector(Vector *v){
    if (v) {
        free(v->dados);
        free(v);
    }
}
void clear(Vector *v){
    v->tamanho = 0;
}

int main(){
    Vector *v = criarVector(2);
    push_back(v, 10);
    push_back(v, 20);
    push(v, 15, 1);

    printf("Tamanho: %d\n", size(v));
    for (int i = 0; i < size(v); i++) {
        printf("%d ", v->dados[i]);
    }

    pop(v, 1);
    pop_Back(v);

    printf("\nApós remoções:\n");
    for (int i = 0; i < size(v); i++) {
        printf("%d ", v->dados[i]);
    }

    clear(v);
    printf("\nTamanho após clear: %d\n", size(v));

    free_vector(v);


}

