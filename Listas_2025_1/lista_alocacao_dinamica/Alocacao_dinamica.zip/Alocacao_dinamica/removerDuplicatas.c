#include<stdio.h>
#include<stdlib.h>

int* removeDuplicates(int* nums, int* numsSize){
    int tamanho_novo=0;
    for(int i=0; i<*numsSize;i++){
        int repetido=0;
        for(int j=0; j<tamanho_novo;j++){
            if(nums[i]==nums[j]){
                repetido=1;
                break;
            }
        }
        if(!repetido){
            nums[tamanho_novo]=nums[i];
            tamanho_novo++;
        }
    }
    *numsSize=tamanho_novo;
    return nums;
}

int main(){
    int *vet; 
    int tamanho; 

    printf("Digite a quantide que deseja colocar no vetor:\n");
    scanf("%d",&tamanho);

    vet=(int*)malloc(tamanho*sizeof(int));

    for(int i=0; i<tamanho; i++){
        printf("Digite o %d elemento\n",i+1);
        scanf("%d",&vet[i]);
    }
    int *resultado= removeDuplicates(vet,&tamanho); 

    for(int i=0; i<tamanho; i++){
        printf(" %d \n", resultado[i]);
    }
}